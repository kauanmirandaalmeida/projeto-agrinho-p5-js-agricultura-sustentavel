// Projeto Agrinho - Agricultura Sstentável

let sol = { x: 100, y: 100, tamanho: 60 };
let nuvens = [];
let plantas = [];
let soloY;
let tempo = 0;
let botaoPlanta;
let grama = []; // Array para armazenar posições da grama

function setup() {
  createCanvas(800, 500);
  soloY = height - 50;

  // Cria nuvens iniciais (sem velocidade)
  for (let i = 0; i < 5; i++) {
    nuvens.push({
      x: random(width),
      y: random(50, 150),
      largura: random(50, 100)
    });
  }

  // Cria vegetação estática (grama)
  for (let x = 0; x < width; x += 5) {
    grama.push({
      x: x,
      altura: random(5, 20) // Altura fixa para a grama
    });
  }

  // Cria botão para plantar
  botaoPlanta = createButton('Plantar Árvore');
  botaoPlanta.position(20, 20);
  botaoPlanta.mousePressed(() => plantarArvore(mouseX));

  // Texto de instrução
  textSize(16);
  fill(0);
}

function draw() {
  // Fundo gradiente (céu)
  setGradient(0, 0, width, soloY, color(135, 206, 235), color(30, 144, 255));

  // Sol
  drawSol();

  // Nuvens (estáticas)
  drawNuvens();

  // Solo
  drawSolo();

  // Plantas
  updatePlantas();

  // Mostra contador de plantas
  fill(255);
  rect(10, 10, 180, 40, 5);
  fill(0);
  text("Plantas cultivadas: " + plantas.length, 20, 35);

  tempo += 0.01;
}

function setGradient(x, y, w, h, c1, c2) {
  noFill();
  for (let i = y; i <= y + h; i++) {
    let inter = map(i, y, y + h, 0, 1);
    let c = lerpColor(c1, c2, inter);
    stroke(c);
    line(x, i, x + w, i);
  }
}

function drawSol() {
  fill(255, 255, 0);
  noStroke();
  ellipse(sol.x, sol.y, sol.tamanho);

  // Raios do sol
  for (let i = 0; i < 12; i++) {
    let angle = i * PI/6 + tempo;
    let x1 = sol.x + cos(angle) * sol.tamanho/2;
    let y1 = sol.y + sin(angle) * sol.tamanho/2;
    let x2 = sol.x + cos(angle) * (sol.tamanho/2 + 15);
    let y2 = sol.y + sin(angle) * (sol.tamanho/2 + 15);
    stroke(255, 255, 0, 200);
    line(x1, y1, x2, y2);
  }
}

function drawNuvens() {
  for (let nuvem of nuvens) {
    fill(255, 255, 255, 200);
    noStroke();
    ellipse(nuvem.x, nuvem.y, nuvem.largura, nuvem.largura/2);
    ellipse(nuvem.x + nuvem.largura/3, nuvem.y - nuvem.largura/6, nuvem.largura/2, nuvem.largura/3);
    ellipse(nuvem.x - nuvem.largura/3, nuvem.y + nuvem.largura/6, nuvem.largura/2, nuvem.largura/3);
  }
}

function drawSolo() {
  // Terra
  fill(139, 69, 19);
  noStroke();
  rect(0, soloY, width, height - soloY);

  // Grama estática
  fill(34, 139, 34);
  for (let g of grama) {
    rect(g.x, soloY - g.altura, 5, g.altura);
  }
}

function plantarArvore(x) {
  // Verifica se a posição está no solo
  if (x < 0) x = 0;
  if (x > width) x = width;
  
  plantas.push({
    x: x,
    tamanho: random(0.8, 1.2),
    crescimento: 0,
    cor: color(random(100, 150), random(150, 200), random(50, 100))
  });
}

function updatePlantas() {
  for (let i = plantas.length - 1; i >= 0; i--) {
    let planta = plantas[i];

    if (planta.crescimento < 1) {
      planta.crescimento += 0.005;
    }

    let h = planta.crescimento * 100 * planta.tamanho;

    // Caule
    fill(139, 69, 19);
    rect(planta.x - 5, soloY - h, 10, h);

    // Copa da árvore
    fill(planta.cor);
    ellipse(planta.x, soloY - h - 10, 40 * planta.tamanho, 60 * planta.tamanho);
  }
}

function mousePressed() {
  // Plantar com clique no solo
  if (mouseY > soloY - 50 && mouseY < height) {
    plantarArvore(mouseX);
  }
}